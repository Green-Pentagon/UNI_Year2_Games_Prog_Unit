#pragma once
#include <vector>
#include <SFML/Graphics.hpp>
#include "TextureManager.h"

using namespace std;

class Enemy
{
	vector<sf::Vector2f> patrol;
	float visibilityRadius;
	float speed;
	float idleTime;
	sf::Sprite spr;
	sf::Vector2f position;
	void InitAssets()
	{
		// texture from https://stealthix.itch.io/animated-slimes
		TextureManager::Instance().AddTexture("assets/Slime_Medium_Green.png", sf::IntRect(0, 0, 32, 32), "slime0");
		TextureManager::Instance().SetTextureFiltering("assets/Slime_Medium_Green.png", false);
		TextureManager::Instance().SetSprite("slime0", spr);
		spr.setOrigin(sf::Vector2f(16, 16));
		spr.setScale(sf::Vector2f(2, 2));
	}
public:
	Enemy(const vector<sf::Vector2f> patrol, float visibilityRadius, float speed, float idleTime) : patrol(patrol), visibilityRadius(visibilityRadius), speed(speed), idleTime(idleTime)
	{
		InitAssets();
	}
	void Update(float dt, const sf::Vector2f& playerPos)
	{
		position = patrol[0];
	}
	void Draw(sf::RenderWindow& window)
	{
		spr.setPosition(position);
		window.draw(spr);
	}
	const vector<sf::Vector2f>& GetPatrol() const { return patrol; }
	const sf::Vector2f& GetPosition() const { return position; }
	float GetSpeed() const { return speed; }
	float GetVisibilityRadius() const { return visibilityRadius; }
	float GetIdleTime() const { return idleTime; }
	void SetPosition(const sf::Vector2f& pos) { position = pos; }
};